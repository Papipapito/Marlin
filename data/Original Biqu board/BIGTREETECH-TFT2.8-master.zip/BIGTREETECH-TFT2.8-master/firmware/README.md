the source code of firmware in [here](https://github.com/bigtreetech/BIGTREETECH-TouchScreenFirmware)
this source code is a TFT35 UI style, and not same as BIQU_TFT28_V1.2.2.bin
